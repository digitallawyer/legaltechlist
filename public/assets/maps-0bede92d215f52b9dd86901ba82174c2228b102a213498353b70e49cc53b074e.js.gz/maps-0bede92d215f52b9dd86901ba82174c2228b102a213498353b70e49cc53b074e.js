import "underscore"

// Initialize global Gmaps object
window.Gmaps = {};
